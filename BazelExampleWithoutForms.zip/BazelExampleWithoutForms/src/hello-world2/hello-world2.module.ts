import {NgModule} from '@angular/core';

import {HelloWorld2Component} from './hello-world2.component';

@NgModule({
  declarations: [HelloWorld2Component],
  exports: [HelloWorld2Component],
})
export class HelloWorld2Module {}