import {Component, NgModule} from '@angular/core';


@Component({
  selector: 'hello-world2-app',
  templateUrl: './hello-world2.html'
})
export class HelloWorld2Component {
  
}
