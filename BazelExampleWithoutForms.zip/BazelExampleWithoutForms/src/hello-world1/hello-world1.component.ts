import {Component, NgModule} from '@angular/core';


@Component({
  selector: 'hello-world1-app',
  templateUrl: './hello-world1.html'
})
export class HelloWorld1Component {
    name = 'Rajan';
}
