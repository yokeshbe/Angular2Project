import {NgModule} from '@angular/core';
import {FormsModule} from '@angular/forms';

import {HelloWorld1Component} from './hello-world1.component';

@NgModule({
  imports: [],
  declarations: [HelloWorld1Component],
  exports: [HelloWorld1Component],
})
export class HelloWorld1Module {}