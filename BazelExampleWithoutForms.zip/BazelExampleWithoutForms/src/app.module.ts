
import {NgModule} from '@angular/core';
import {BrowserModule} from '@angular/platform-browser';
import { FormsModule } from '@angular/forms';

import {AppComponent} from './app.component';
import {HelloWorldModule} from './hello-world/hello-world.module';
import {HelloWorld1Module} from './hello-world1/hello-world1.module';
import {HelloWorld2Module} from './hello-world2/hello-world2.module';

@NgModule({
  imports: [BrowserModule, HelloWorldModule, 
    HelloWorld1Module, HelloWorld2Module, 
  //  FormsModule
  ],
  declarations: [AppComponent],
  bootstrap: [AppComponent],
})
export class AppModule {}
