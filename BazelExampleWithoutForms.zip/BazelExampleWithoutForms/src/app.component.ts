import {Component} from '@angular/core';

@Component({selector: 'app-component', 
            template: '<hello-world-app></hello-world-app><hello-world1-app></hello-world1-app><hello-world2-app></hello-world2-app>'})
export class AppComponent {}
