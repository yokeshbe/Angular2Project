import { Component } from '@angular/core';
@Component({
  selector: 'app-main',
  template: '<h1>Hellos, {{name}}</h1>'
})
export class AppComponent {
  name = 'Angular World';
}