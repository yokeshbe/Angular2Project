import { Component } from '@angular/core';
 import { DomSanitizer } from '@angular/platform-browser'

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'app';

  content = null;

  constructor(protected sanitizer: DomSanitizer) {}

  clickHandler() {
    this.content = this.sanitizer.bypassSecurityTrustHtml('<app-grid></app-grid');
  }
}
