import { NgModule, Injector } from '@angular/core';
import { CommonModule } from '@angular/common';
import { GridComponent } from './grid.component';
import {AgGridModule} from 'ag-grid-angular/main';
import { createCustomElement } from '@angular/elements';

@NgModule({
  imports: [
    CommonModule,
       AgGridModule.withComponents(
            [GridComponent]
        )
  ],
  declarations: [GridComponent],
  entryComponents: [GridComponent ]
})
export class GridModule {

  constructor(private injector: Injector) {
    const customButton = createCustomElement(GridComponent, { injector });
    customElements.define('app-grid', customButton);
  }

  ngDoBootstrap() {}
 }
