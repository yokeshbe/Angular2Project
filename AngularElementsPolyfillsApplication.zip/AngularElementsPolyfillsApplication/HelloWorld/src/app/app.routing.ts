import { Routes } from '@angular/router';
import { FirstComponent } from './first/first.component';
import { SecondComponent } from './second/second.component';


export const AppRoutes: Routes = [
     {
         path: 'helloWorld/first',
        //  loadChildren: './first/first.module#FirstModule',
         component: FirstComponent
     },
     {
         path: 'helloWorld/second',
        //  loadChildren: './second/second.module#SecondModule',
         component: SecondComponent
     }
    //  {
    //      redirectTo: '/first',
    //      pathMatch: 'full'
    //  }
]