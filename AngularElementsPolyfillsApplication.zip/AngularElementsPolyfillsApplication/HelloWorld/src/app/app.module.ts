import { BrowserModule } from '@angular/platform-browser';
import { NgModule, Injector } from '@angular/core';

import { AppComponent } from './app.component';

import { createCustomElement } from '@angular/elements';

import { Routes, RouterModule } from '@angular/router';
import {AppRoutes} from './app.routing';

import { FirstComponent } from './first/first.component';
import { SecondComponent } from './second/second.component';

@NgModule({
  declarations: [
    AppComponent,
    FirstComponent,
    SecondComponent
  ],
  imports: [
    BrowserModule,
    RouterModule.forRoot(AppRoutes, {useHash: true})
  ],
  providers: [],
  // bootstrap: [AppComponent],
  entryComponents: [AppComponent]
})
export class AppModule {

  constructor(private injector: Injector) {
    const helloWorldContainer = createCustomElement(AppComponent, { injector });
    customElements.define('app-hello-world', helloWorldContainer);
  }

  ngDoBootstrap() {}

 }
