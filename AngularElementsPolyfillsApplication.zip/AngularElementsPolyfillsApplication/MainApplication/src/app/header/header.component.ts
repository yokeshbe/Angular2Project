import { Component, OnInit } from '@angular/core';
import { AppComponent } from '../app.component';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {

  constructor(private appComponent: AppComponent) { }

  ngOnInit() {
  }

  menu_ClickHandler(name){

  }

  mfop_clickHandler() {
    this.appComponent.mfop_clickHandler();
  }

  helloWorld_clickHandler() {
    this.appComponent.helloWorld_clickHandler();
  }

  mfopGrid_clickHandler() {
    this.appComponent.mfopGrid_clickHandler();
  }

}
