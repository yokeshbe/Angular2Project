import { Component, OnInit } from '@angular/core';
import { DomSanitizer } from '@angular/platform-browser';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit{
  title = 'app';

  content = null;

  constructor(protected sanitizer: DomSanitizer) {}

  ngOnInit() {
    this.content = '';
  }

  mfop_clickHandler() {
    console.log('MFOP click Handler called');
    this.content = this.sanitizer.bypassSecurityTrustHtml(' <app-mfop></app-mfop>');
  }

 helloWorld_clickHandler() {
    console.log('Hello World click Handler called');
    this.content = this.sanitizer.bypassSecurityTrustHtml('<app-hello-world></app-hello-world>');
  }

   mfopGrid_clickHandler() {
    console.log('MFOP Grid click Handler called');
    this.content = this.sanitizer.bypassSecurityTrustHtml('<app-mfop-grid></app-mfop-grid>');
  }

}
