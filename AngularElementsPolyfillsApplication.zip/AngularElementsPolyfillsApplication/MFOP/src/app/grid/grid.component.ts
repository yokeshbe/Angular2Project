import { Component, OnInit } from '@angular/core';
import {GridOptions} from "ag-grid";
import { HttpClient} from  '@angular/common/http';
import { map } from 'rxjs/operators';

@Component({
  selector: 'app-mfop-grid',
  templateUrl: './grid.component.html',
  styleUrls: ['./grid.component.css']
})
export class GridComponent implements OnInit {

public gridOptions: GridOptions;

restItems: any;
restItemsUrl = 'assets/data/userDetails.json';


  constructor(private  http:  HttpClient) { 
    this.gridOptions = <GridOptions>{};
        this.gridOptions.columnDefs = [
            {
                headerName: "ID",
                field: "id",
                width: 400
            },
            {
                headerName: "Name",
                field: "name",

                width: 500
            },

        ];

         this.gridOptions.rowData = [
            {id: 5, value: 10},
            {id: 10, value: 15},
            {id: 15, value: 20}
        ]
  }

  ngOnInit() {
      this.getRestItems();
  }
    // Read all REST Items
    getRestItems(): void {
        this.restItemsServiceGetRestItems()
        .subscribe(
            restItems => {
            this.restItems = restItems;
            console.log(this.restItems);
            }
        )
    }

    // Rest Items Service: Read all REST Items
    restItemsServiceGetRestItems() {
        return this.http
        .get<any[]>('https://jsonplaceholder.typicode.com/users')
        .pipe(map(data => data));
    }
   

}
