import { NgModule, Injector } from '@angular/core';
import { CommonModule } from '@angular/common';
import { GridComponent } from './grid.component';
import {AgGridModule} from 'ag-grid-angular/main';
import { createCustomElement } from '@angular/elements';
import { HttpClientModule } from  '@angular/common/http';

@NgModule({
  imports: [
    CommonModule,
    HttpClientModule,
       AgGridModule.withComponents(
            [GridComponent]
        )
  ],
  declarations: [],
  entryComponents: [GridComponent ]
})
export class GridModule {

  constructor(private injector: Injector) {
    const customGrid = createCustomElement(GridComponent, { injector });
    customElements.define('app-mfop-grid', customGrid);
  }

  ngDoBootstrap() {}
 }
