import { BrowserModule } from '@angular/platform-browser';
import { NgModule, Injector } from '@angular/core';

import { AppComponent } from './app.component';

import {createCustomElement} from '@angular/elements';

import { GridModule } from './grid/grid.module';

import { Routes, RouterModule } from '@angular/router';
import {AppRoutes} from './app.routing';
import { FirstComponent } from './first/first.component';
import { SecondComponent } from './second/second.component';
import { GridComponent } from './grid/grid.component';
import { AgGridModule } from 'ag-grid-angular/main';

@NgModule({
  declarations: [
    AppComponent,
    FirstComponent,
    SecondComponent,
    GridComponent
  ],
  imports: [
    BrowserModule,
    GridModule,
    RouterModule.forRoot(AppRoutes, {useHash: true}),
     AgGridModule.withComponents(
            [GridComponent]
        )
  ],
  providers: [],
  // bootstrap: [AppComponent],
  entryComponents: [AppComponent]
})
export class AppModule { 

  constructor(private injector: Injector) {
    // const customButton = createCustomElement(AppComponent, { injector });
    // customElements.define('app-grid-root', customButton);
  }

  ngDoBootstrap() {
     const customButton = createCustomElement(AppComponent, { injector: this.injector });
    customElements.define('app-mfop', customButton);
  }
}
