import { Routes } from '@angular/router';
import { FirstComponent } from './first/first.component';
import { SecondComponent } from './second/second.component';
import { GridComponent } from './grid/grid.component';

export const AppRoutes: Routes = [
     {
         path: 'mfop/first',
        //  loadChildren: './first/first.module#FirstModule',
         component: FirstComponent
     },
     {
         path: 'mfop/second',
        //  loadChildren: './second/second.module#SecondModule',
         component: SecondComponent
     },
     {
         path: 'mfop/grid',
         component: GridComponent
     }
    //  {
    //      redirectTo: '/first',
    //      pathMatch: 'full'
    //  }
]