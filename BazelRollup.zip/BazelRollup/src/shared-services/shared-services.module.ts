import {NgModule} from '@angular/core';
import { RouterModule } from '@angular/router';
import { CommonModule } from '@angular/common';

import { ServiceManager } from './service.manager';

//import { HelloWorldRoutes } from './hello-world.routing';





@NgModule({
  imports: [
      CommonModule
  ],
  declarations: [ServiceManager],
  exports: [],
})
export class HelloWorldModule {}