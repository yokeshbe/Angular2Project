import {NgModule} from '@angular/core';
import { RouterModule } from '@angular/router';


//import { HelloWorldRoutes } from './hello-world.routing';

import {HelloWorld1Component} from './hello-world1.component';



@NgModule({
  imports: [RouterModule.forChild([
    {
      path: '',
      component: HelloWorld1Component}
  ])],
  declarations: [HelloWorld1Component],
  exports: [HelloWorld1Component],
})
export class HelloWorld1Module {}