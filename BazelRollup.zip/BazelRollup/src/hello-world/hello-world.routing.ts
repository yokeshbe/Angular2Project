import { RouterModule, Routes } from '@angular/router';
import { HelloWorldComponent } from './hello-world.component';

export const HelloWorldRoutes: Routes = [
    {
        path: '',
        component: HelloWorldComponent
    }
];


