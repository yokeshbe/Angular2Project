import {Component, NgModule, OnInit} from '@angular/core';
import {msg} from '../lib/file';
import { ServiceManager } from '../shared-services/service.manager';

@Component({
  selector: 'hello-world-app',
  template: `
    <div>Hello Rajan{{ name }}</div>
    <input type="text" [value]="name" (input)="name = $event.target.value"/>
  `,
  styleUrls: ['./hello-world-styles.css']
})
export class HelloWorldComponent implements OnInit{
  name: string = msg;

  // constructor(private serviceManager: ServiceManager){}

  ngOnInit() {
   // console.log('servicemanage: ', this.serviceManager);
  }

}
