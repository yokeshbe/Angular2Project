import { RouterModule, Routes } from '@angular/router';
import {ModuleWithProviders} from '@angular/core';

export const AppRoutes: Routes = [
    {
        path: '',
        redirectTo: '/hello',
        pathMatch: 'full'
      },
    {
        path: 'hello',
        loadChildren: '/hello-world/hello-world.module#HelloWorldModule'
    },
    {
        path: 'helloworld1',
        loadChildren: '/hello-world1/hello-world1.module#HelloWorld1Module'
    }
];

export const routing: ModuleWithProviders = RouterModule.forRoot(AppRoutes);
