export const msg: string = 'World';
