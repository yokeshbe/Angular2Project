
import {NgModule} from '@angular/core';
import {BrowserModule} from '@angular/platform-browser';

import {AppComponent} from './app.component';
import {HelloWorldModule} from './hello-world/hello-world.module';

import { RouterModule } from '@angular/router';
 import {AppRoutes} from './app.routing';

// import {routing} from './app.routing';

@NgModule({
  imports: [BrowserModule, HelloWorldModule,
  RouterModule.forRoot(AppRoutes)
  // routing
],
  declarations: [AppComponent],
  bootstrap: [AppComponent],
})
export class AppModule {}
