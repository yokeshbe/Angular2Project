import {Component} from '@angular/core';

@Component({selector: 'app-component', 
template: '<h1>App Components</h1><a routerLink="hello">Hello</a><br><a routerLink="helloworld1">Hello World1</a><br><router-outlet></router-outlet>'})
export class AppComponent {}