export class HelloWorldService {
  getMessage() {
    return 'Hello World App!';
  }
}