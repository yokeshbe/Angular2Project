import { Component, OnInit } from '@angular/core';
import { Subscription } from 'rxjs/Subscription';
import { EmployeeService } from './service/employee.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  title = 'app';
  loaderPath = 'assets/images/loader.gif';
  showProgress:boolean;
  loaderSubscription: Subscription;

  constructor(private _empService: EmployeeService) {

  }

  ngOnInit() {
      this.loaderSubscription = this._empService.loaderChange.subscribe((loaderStatus:boolean) => {
        this.showProgress = loaderStatus;
      })
  }

  ngOnDestroy() {
        this.loaderSubscription.unsubscribe();
  }

}
