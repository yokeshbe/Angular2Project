import { Component, OnInit } from '@angular/core';
import { EmployeeService } from '../service/employee.service';

@Component({
  selector: 'app-employee-list',
  templateUrl: './employee-list.component.html',
  styleUrls: ['./employee-list.component.css']
})
export class EmployeeListComponent implements OnInit {

  employees = [];
  errorMsg:string = "";

  constructor(private  _empService: EmployeeService) { }

  ngOnInit() {
    this._empService.getEmployees().subscribe(result => {
        console.log('result:',result);
        this.employees = result.records;
    },
     resEmployeeError => this.errorMsg = resEmployeeError);
  }

}
