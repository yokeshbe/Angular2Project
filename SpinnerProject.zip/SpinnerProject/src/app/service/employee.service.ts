import { Injectable } from '@angular/core';
import { Http,Response } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch'
import 'rxjs/add/observable/throw';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';

@Injectable()
export class EmployeeService{
     
    private _url : string = "https://www.w3schools.com/angular/customers.php";

    public _showLoader: boolean = true;

    loaderChange: BehaviorSubject<boolean> = new BehaviorSubject<boolean>(false);

    constructor(private _http:Http){}
    
    getEmployees(){
        this._showLoader = true;
        this.loaderChange.next(this._showLoader);
        
        return this._http.get(this._url)
        .map((response: Response) => {
            this._showLoader = false;
            this.loaderChange.next(this._showLoader);
            response;
        })
                .catch((error:Response) => {
                      this._showLoader = false;
                      this.loaderChange.next(this._showLoader);
                      return Observable.throw(error || "Server Error");
                });
      
       
    }

}