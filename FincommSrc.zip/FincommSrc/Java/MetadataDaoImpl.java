package com.restws.dao.impl;

import java.io.IOException;

import javax.ws.rs.GET;

import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.json.XML;

import org.codehaus.jackson.map.ObjectMapper;
import org.json.JSONObject;

@Path("/metadata")
public class MetadataDaoImpl {

	@POST
	@Path("/getMetadata")
	//@Produces(MediaType.APPLICATION_JSON)
	@Produces("application/json")
	public Response saveMetadata(MetadataVO metadataVO) throws IOException{
		
		ObjectMapper mapperObj = new ObjectMapper();
		String jsonStr = mapperObj.writeValueAsString(metadataVO);
		System.out.println("JSON string: "+jsonStr);
		JSONObject jsonObj = new JSONObject(jsonStr);
		String xmlStr = XML.toString(jsonObj,"metadata");
		System.out.println("XML string: "+xmlStr);

		return Response.status(200).entity("Success").build();
	}
	
	@GET
	@Produces(MediaType.TEXT_PLAIN)
	public String getMetadata() {
		return "Welcome getMetadata";
	}
}
