package com.restws.dao.impl;

import java.io.Serializable;

public class MetadataVO implements Serializable{

		private String name;
		private String type;
		//private String datatype;
		private String dataType;
		
		public String getName() {
			return name;
		}
		public void setName(String name) {
			this.name = name;
		}
		public String getType() {
			return type;
		}
		public void setType(String type) {
			this.type = type;
		}
		public String getDataType() {
			return dataType;
		}
		public void setDataType(String dataType) {
			this.dataType = dataType;
		}
		
		
	
		
}
