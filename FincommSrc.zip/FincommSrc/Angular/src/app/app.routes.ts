import { Routes } from '@angular/router';
import { ManageStatementComponent } from './manage-statement/manage-statement.component';
import { CreateMetadataComponent } from './create-metadata/create-metadata.component';

export const AppRoute: Routes = [
    {
        path: '',
        component: ManageStatementComponent
    },
    {
        path: 'createMetadata',
        component: CreateMetadataComponent
    }
];
