import { Component, OnInit } from '@angular/core';
import {  DropdownModule } from 'primeng/primeng';
import { ServiceManager } from '../shared/services/service.manager';
import { URLManager } from '../shared/services/url.manager';
import { MetadataVO } from './metadata.vo';

@Component({
  selector: 'app-create-metadata',
  templateUrl: './create-metadata.component.html',
  styleUrls: ['./create-metadata.component.css']
})
export class CreateMetadataComponent implements OnInit {

    mdType = [];
    mdCategoryType = [];
    selectedMdType: any;
    selectedMdDataType: any;
    metadataName= 'md1';
    successMsg = '';
    metadataVO = new MetadataVO();

  constructor(private _serviceManager: ServiceManager) {
        this.mdType = [];
        this.mdType.push({label: 'Text', value: 'text'});
        this.mdType.push({label: 'Table', value: 'table'});
        this.mdCategoryType = [];
        this.mdCategoryType.push({label: 'Static', value: 'static'});
        this.mdCategoryType.push({label: 'Dynamic', value: 'dynamic'});
        // this.mdCategoryType.push({label: 'Dynamic', value: {id: 1, name: 'Dynamic', code: 'dynamic'}});
   }

  ngOnInit() {
  }

  submitHandler(value: any) {
      console.log('Values:', value);
      this.metadataVO.name = this.metadataName;
      this.metadataVO.type = value.type;
      this.metadataVO.dataType = value.dataType;
      console.log('Metadata:', this.metadataVO);

      this._serviceManager.saveData(URLManager.SAVE_METADATA, this.metadataVO)
                          .subscribe(result =>  this.successMsg = result);
  }

}
