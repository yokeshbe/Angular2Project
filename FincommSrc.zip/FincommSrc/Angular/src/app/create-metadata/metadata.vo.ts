export class MetadataVO {
    name: string;
    type: string;
    dataType: string;
}
