import { Component, OnInit } from '@angular/core';
import { ServiceManager } from '../shared/services/service.manager';
import { URLManager } from '../shared/services/url.manager';
import { ButtonModule } from 'primeng/primeng';
// import 'rxjs/observable';

@Component({
  selector: 'app-manage-statement',
  templateUrl: './manage-statement.component.html',
  styleUrls: ['./manage-statement.component.css']
})

export class ManageStatementComponent implements OnInit {

  statements = [];
  errorMsg = '';

  constructor(private _serviceManager: ServiceManager) { }

  ngOnInit() {
      this._serviceManager.getServiceData(URLManager.GET_MANAGEMENT_DATA)
                        .subscribe((respStatements) => this.statements = respStatements,
                                    (responseError) => this.errorMsg = responseError);
  }

}
