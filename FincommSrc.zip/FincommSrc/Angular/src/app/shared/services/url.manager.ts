export class URLManager {

    public static  GET_MANAGEMENT_DATA = 'http://localhost:8080/CXFRestWS/rest/userStatements/getStatement';
    // "assets/apidata/statementdata.json";

    public static SAVE_METADATA = 'http://localhost:8080/SampleREST/rest/metadata/getMetadata';
 }
