import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpModule } from '@angular/http';
import { FormsModule } from '@angular/forms';
import { ServiceManager } from './shared/services/service.manager';
import { URLManager } from './shared/services/url.manager';
import { ButtonModule, DropdownModule,  DataTableModule} from 'primeng/primeng';
import { DataGridModule } from 'primeng/primeng';

import { AppComponent } from './app.component';
import { PdfViewerComponent } from 'ng2-pdf-viewer';
import { TopBarComponent } from './top-bar/top-bar.component';
import { MenuBarComponent } from './menu-bar/menu-bar.component';
import { MainContainerComponent } from './main-container/main-container.component';
import { ManageStatementComponent } from './manage-statement/manage-statement.component';
import { CreateMetadataComponent } from './create-metadata/create-metadata.component';

import { AppRoute } from './app.routes';
import { RouterModule } from '@angular/router';


@NgModule({
  declarations: [
    AppComponent, TopBarComponent, MenuBarComponent, MainContainerComponent, ManageStatementComponent, CreateMetadataComponent
  ],
  imports: [
    BrowserAnimationsModule, BrowserModule, HttpModule, FormsModule,
    ButtonModule, DataGridModule, DataTableModule, DropdownModule,
    RouterModule.forRoot(AppRoute)
  ],
  providers: [ ServiceManager  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
