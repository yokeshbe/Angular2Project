
import {NgModule} from '@angular/core';
import {BrowserModule} from '@angular/platform-browser';

import {AppComponent} from './app.component';
import {HelloWorldModule} from './hello-world/hello-world.module';

import { ServiceManager } from './shared-services/service.manager';

@NgModule({
  imports: [BrowserModule, HelloWorldModule],
  declarations: [AppComponent],
  bootstrap: [AppComponent],
  providers: [ServiceManager]
})
export class AppModule {}
