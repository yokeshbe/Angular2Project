import {Component} from '@angular/core';

@Component({selector: 'app-component', template: '<hello-world-app></hello-world-app>'})
export class AppComponent {}
