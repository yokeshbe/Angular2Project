import {Component, NgModule, OnInit} from '@angular/core';
import {Http} from '@angular/http';
import {msg} from '../lib/file';

import 'rxjs/add/operator/map';
import {Observable} from 'rxjs/Observable';

 import { ServiceManager1 } from './service.manager';

 import { ServiceManager } from '../shared-services/service.manager';

 import {URLManager} from '../shared-services/URL.Manager';

@Component({
  selector: 'hello-world-app',
  template: `
    <div>{{name}}</div>
    <input type="text" [value]="name" (input)="name = $event.target.value"/>
  <div>{{sampleResponse}}</div>`,
  styleUrls: ['./hello-world-styles.css']
})
export class HelloWorldComponent implements OnInit {
  name = "Hello";
  //headline: Observable<string>;
  headline: any;

  sampleResponse: any;

  constructor(private http: Http
  , private servicemanager1: ServiceManager1,
  private servicemanager: ServiceManager) {
    console.log('servicemanager', this.servicemanager);
    console.log('servicemanager1', this.servicemanager1);
  }

  ngOnInit() {

    this.servicemanager1.getServiceDatas(URLManager.GET_DATA)
        .subscribe((result: any) => {
                console.log('result:', result);
                this.sampleResponse = JSON.stringify(result);
        });
  }
}
