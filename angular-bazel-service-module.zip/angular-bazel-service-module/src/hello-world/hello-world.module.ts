import {NgModule} from '@angular/core';
import {HttpModule} from '@angular/http';
import {CommonModule} from '@angular/common';
import { SharedServicesModule } from '../shared-services/shared-services.module';

import {HelloWorldComponent} from './hello-world.component';

 import { ServiceManager1 } from './service.manager';
 import { ServiceManager } from '../shared-services/service.manager';



@NgModule({
  imports: [HttpModule, CommonModule],
  declarations: [HelloWorldComponent],
  exports: [HelloWorldComponent],
   providers: [ServiceManager1
  ,ServiceManager]
})
export class HelloWorldModule {}