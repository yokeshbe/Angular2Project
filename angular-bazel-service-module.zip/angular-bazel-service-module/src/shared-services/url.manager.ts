export class URLManager {
    public static GET_DATA: string = 'https://jsonplaceholder.typicode.com/users';
}