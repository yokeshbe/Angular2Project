import {NgModule} from '@angular/core';

import { CommonModule,  } from '@angular/common';

import { ServiceManager } from './service.manager';
import { ModuleWithProviders } from '@angular/core';






@NgModule({
  imports: [
      CommonModule
  ],
  declarations: [ServiceManager],
  exports: [ServiceManager],
})
export class SharedServicesModule {
  static forRoot(): ModuleWithProviders { // this kinda tells "module + providers"
        return {
          ngModule: SharedServicesModule, // take the normal version
            providers: [ // merge this to the providers array of the normal version
              ServiceManager,
                
            ]
        };
    }
}