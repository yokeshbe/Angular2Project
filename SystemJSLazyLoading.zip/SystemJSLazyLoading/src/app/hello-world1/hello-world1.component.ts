import {Component, NgModule} from '@angular/core';


@Component({
  selector: 'hello-world1-app',
  template: `
    <h2>Hello World 1 Module</h2>
   
  `,
  
})
export class HelloWorld1Component {
 
}
