import {NgModule} from '@angular/core';
import { RouterModule } from '@angular/router';
import {HelloWorldComponent} from './hello-world.component';

@NgModule({
  imports: [
      RouterModule.forChild([
          {
              path:'',
              component: HelloWorldComponent
          }
      ])
  ],  
  declarations: [HelloWorldComponent],
  exports: [HelloWorldComponent],
})
export class HelloWorldModule {}