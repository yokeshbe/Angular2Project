import {Component, NgModule} from '@angular/core';


@Component({
  selector: 'hello-world-app',
  template: `
    <h2>Hello World Module</h2>
   
  `,
  
})
export class HelloWorldComponent {
 
}
