import { Component } from '@angular/core';
@Component({
  selector: 'app-main',
  template: `<h1>Hello, {{name}}</h1>
    <a [routerLink]="['/hello']">Hello</a>
     <a [routerLink]="['/hello1']">Hello1</a>
     <a routerLink="['hello']">Hello</a>
  <router-outlet></router-outlet>`
})
export class AppComponent {
  name = 'Angular World';
}