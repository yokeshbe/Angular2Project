import { RouterModule, Routes} from '@angular/router';
import { HelloWorldComponent } from './hello-world/hello-world.component';

export const AppRoutes: Routes = [
    {
        path : 'hello',
       loadChildren : 'app/hello-world/hello-world.module#HelloWorldModule'
    //    component: HelloWorldComponent
    },
    {
        path : 'hello1',
       loadChildren : 'app/hello-world1/hello-world1.module#HelloWorld1Module'
    //    component: HelloWorldComponent
    },
    {
        path:'',
        redirectTo: 'hello',
        pathMatch: 'full'
    }
] 