import { AppComponent } from './app.component';
import { NgModule, Injector } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { RouterModule } from '@angular/router';
import { AppRoutes } from './app.routing';

import {HelloWorldComponent} from './hello-world/hello-world.component';

// import {createCustomElement} from '@angular/elements';

@NgModule({
  imports: [BrowserModule,
  RouterModule.forRoot(AppRoutes)
  ],
  declarations: [AppComponent ],
  bootstrap: [AppComponent]
})
export class AppModule {
	
	// constructor(private injector: Injector) {
	// 	const customElement = createCustomElement(AppComponent, { injector });
	// 	customElements.define('app-component', customElement);
  // }
}