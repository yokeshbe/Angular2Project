System.config({
    meta:{
        '@angular/*':{
            build: false
        },
        'rxjs/*': {
            build: false
        }
    },
    paths:{
        "dist/*": "./dist/*.js"
    }
});